﻿using System.ComponentModel;

namespace Final_Simple_CRUD.Models
{
    public class Produto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int IdCategory { get; set; }
        public virtual Categoria Category { get; set; }
    }
}
