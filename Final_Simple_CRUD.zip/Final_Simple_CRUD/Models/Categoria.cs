﻿namespace Final_Simple_CRUD.Models
{
    public class Categoria
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public List<Produto> Produtos { set; get; }

    }
}
