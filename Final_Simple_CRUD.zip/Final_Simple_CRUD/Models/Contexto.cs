﻿using Final_Simple_CRUD.Models;
using Microsoft.EntityFrameworkCore;

namespace ProjOmega.Models
{
    public class Contexto : DbContext
    {
        public Contexto(DbContextOptions<Contexto> options) : base(options)
        {
        }

        public DbSet<Produto> Produto { get; set; }
        public DbSet<Categoria> Categoria { get; set; }
    }
}
