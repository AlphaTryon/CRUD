﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ProjOmega.Migrations
{
    /// <inheritdoc />
    public partial class Xis : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Categoria",
                columns: table => new
                {
                    Comida = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Bebida = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Categoria", x => x.Comida);
                });

            migrationBuilder.CreateTable(
                name: "ProdutoCategoria",
                columns: table => new
                {
                    NomeId = table.Column<int>(type: "int", nullable: false),
                    Id1 = table.Column<int>(type: "int", nullable: false),
                    CategoriasID = table.Column<int>(type: "int", nullable: false),
                    ID1 = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.ForeignKey(
                        name: "FK_ProdutoCategoria_Categoria_CategoriasID",
                        column: x => x.CategoriasID,
                        principalTable: "Categoria",
                        principalColumn: "Comida",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ProdutoCategoria_Categoria_ID1",
                        column: x => x.ID1,
                        principalTable: "Categoria",
                        principalColumn: "Comida",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ProdutoCategoria_Produto_Id1",
                        column: x => x.Id1,
                        principalTable: "Produto",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ProdutoCategoria_Produto_NomeId",
                        column: x => x.NomeId,
                        principalTable: "Produto",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ProdutoCategoria_CategoriasID",
                table: "ProdutoCategoria",
                column: "CategoriasID");

            migrationBuilder.CreateIndex(
                name: "IX_ProdutoCategoria_Id1",
                table: "ProdutoCategoria",
                column: "Id1");

            migrationBuilder.CreateIndex(
                name: "IX_ProdutoCategoria_ID1",
                table: "ProdutoCategoria",
                column: "ID1");

            migrationBuilder.CreateIndex(
                name: "IX_ProdutoCategoria_NomeId",
                table: "ProdutoCategoria",
                column: "NomeId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ProdutoCategoria");

            migrationBuilder.DropTable(
                name: "Categoria");
        }
    }
}
