﻿using Microsoft.EntityFrameworkCore;

namespace ProjOmega.Models
{
    public class Contexto : DbContext
    {
        public Contexto(DbContextOptions<Contexto> options) : base(options)
        {
        }

        public DbSet<Produto> Produto { get; set; }
        public DbSet<Categoria> Categoria { get; set; }
        public DbSet<ProdutoCategoria> ProdutoCategoria { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ProdutoCategoria>()
                .ToTable("ProdutoCategoria") // Defina o nome da tabela
                .HasNoKey();
            base.OnModelCreating(modelBuilder);
        }
    }
}


