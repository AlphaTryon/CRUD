﻿using System.ComponentModel.DataAnnotations;

namespace ProjOmega.Models
{
    public class ProdutoCategoria
    {
        public Produto Nome { get; set; }
        public Produto Id { get; set; }
        public Categoria Categorias { get; set; }
        public Categoria ID { get; set; }
    }
}
