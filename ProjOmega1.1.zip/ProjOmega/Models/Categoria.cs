﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProjOmega.Models
{
    [Table("Categoria")]
    public class Categoria
    {
        [Column("Comida")]
        [Display(Name = "Food")]
        public int ID { get; set; }


        [Column("Bebida")]
        [Display(Name = "Drink")]
        public string Categorias { get; set; }
    }
}
